#!/sbin/sh

uninstall_package() {
    ui_print "- Uninstalling $package_title"
    # Remove the files when we're uninstalling NiKGapps
    for i in $file_list; do
        uninstall_file "$i" "$package_name"
    done

    addon_file="51-"$package_title".sh"
    # Removing the addon sh so it doesn't get backed up and restored
    addToLog "- Removing $addon_file"
    rm -rf "/system/addon.d/$addon_file"
    # Removing the updates and residue
    if [ -n "$2" ]; then
        for i in $(find /data -iname "*$2*" 2>/dev/null); do
            if [ -e "$i" ] || [ -d "$1"]; then
                addToLog "- contents matching $2 found at $i"
                rm -rf "$i"
            fi
        done
    fi
}

# Initialize the variables
clean_flash_only="false"
title="ExtraFiles"
package_title="ExtraFiles"
package_name=""

file_list="
___etc___preferred-apps/google.xml
___etc___default-permissions/nikgapps-permissions.xml
___etc___default-permissions/default-permissions.xml
___etc___default-permissions/default-permissions-google.xml
___etc___sysconfig/preinstalled-packages-product-pixel-2017-and-newer.xml
___etc___sysconfig/google-staged-installer-whitelist.xml
___etc___sysconfig/nexus.xml
___etc___sysconfig/nga.xml
___etc___sysconfig/backup.xml
___etc___sysconfig/google-rollback-package-whitelist.xml
___etc___sysconfig/google_vr_build.xml
___etc___sysconfig/google.xml
___etc___sysconfig/google-hiddenapi-package-whitelist.xml
___etc___sysconfig/google_build.xml
___etc___sysconfig/pixel_exclusives.xml
___lib64/libgdx.so
___etc___permissions/privapp-permissions-google-product.xml
___etc___permissions/privapp-permissions-google-comms-suite.xml
___etc___permissions/NikGapps-privapp-permissions-google.xml
___etc___permissions/com.google.android.dialer.support.xml
___etc___permissions/privapp-permissions-google-system-ext.xml
___etc___permissions/split-permissions-google.xml
___etc___permissions/privapp-permissions-google-p.xml
___etc___permissions/privapp-permissions-hotword.xml
___overlay/GmsConfigOverlayCommon.apk
___overlay/GmsContactsProviderOverlay.apk
___overlay/GmsConfigOverlayGSA.apk
___framework/com.google.android.media.effects.jar
___framework/com.google.android.dialer.support.jar
___framework/com.google.widevine.software.drm.jar
___framework/com.google.android.maps.jar
"

uninstall_package
