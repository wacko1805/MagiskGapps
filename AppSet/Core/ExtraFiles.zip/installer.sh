#!/sbin/sh
configValue="$1"
nikgapps_config_file_name="$2"
install_partition="$3"

make_dir() {
  addToLog "- Creating Directory: $install_partition/$1"
  mkdir -p "$install_partition/$1"
  set_perm 1000 1000 0755 "$install_partition/$1"
}

get_prop_file_path() {
  propFilePath=""
  for i in $(find /system/etc/permissions -iname "$package_title.prop" 2>/dev/null;); do
    prop_file_path="$i"
    addToLog "- Found prop file: $prop_file_path"
    break
  done
  addToLog "- Prop file path before: $prop_file_path"
  [ -z "$prop_file_path" ] && prop_file_path="/system/etc/permissions/$package_title.prop"
  addToLog "- Prop file path after: $prop_file_path"
  echo "$prop_file_path"
}
# Initialize the variables
default_partition="product"
clean_flash_only="false"
product_prefix=$(find_product_prefix "$install_partition")
title="ExtraFiles"
package_title="ExtraFiles"
pkg_size="837"
package_name=""
packagePath=installExtraFilesFiles
deleteFilesPath=deleteExtraFilesFiles
propFilePath=$(get_prop_file_path)

remove_aosp_apps_from_rom="
"

file_list="
___etc___preferred-apps/google.xml
___etc___default-permissions/nikgapps-permissions.xml
___etc___default-permissions/default-permissions.xml
___etc___default-permissions/default-permissions-google.xml
___etc___sysconfig/preinstalled-packages-product-pixel-2017-and-newer.xml
___etc___sysconfig/google-staged-installer-whitelist.xml
___etc___sysconfig/nexus.xml
___etc___sysconfig/nga.xml
___etc___sysconfig/backup.xml
___etc___sysconfig/google-rollback-package-whitelist.xml
___etc___sysconfig/google_vr_build.xml
___etc___sysconfig/google.xml
___etc___sysconfig/google-hiddenapi-package-whitelist.xml
___etc___sysconfig/google_build.xml
___etc___sysconfig/pixel_exclusives.xml
___lib64/libgdx.so
___etc___permissions/privapp-permissions-google-product.xml
___etc___permissions/privapp-permissions-google-comms-suite.xml
___etc___permissions/NikGapps-privapp-permissions-google.xml
___etc___permissions/com.google.android.dialer.support.xml
___etc___permissions/privapp-permissions-google-system-ext.xml
___etc___permissions/split-permissions-google.xml
___etc___permissions/privapp-permissions-google-p.xml
___etc___permissions/privapp-permissions-hotword.xml
___overlay/GmsConfigOverlayCommon.apk
___overlay/GmsContactsProviderOverlay.apk
___overlay/GmsConfigOverlayGSA.apk
___framework/com.google.android.media.effects.jar
___framework/com.google.android.dialer.support.jar
___framework/com.google.widevine.software.drm.jar
___framework/com.google.android.maps.jar
"

remove_existing_package() {
   # remove the existing folder for clean install of ExtraFiles
   delete_package "ExtraFiles"
}

remove_aosp_apps() {
   # Delete the folders that we want to remove with installing ExtraFiles
   for i in $remove_aosp_apps_from_rom; do
       RemoveAospAppsFromRom "$i" "$propFilePath"
   done
}

install_package() {
   remove_existing_package
   remove_aosp_apps
   # Create folders and set the permissions
   make_dir "etc/preferred-apps"
   make_dir "etc/default-permissions"
   make_dir "etc/sysconfig"
   make_dir "lib64"
   make_dir "etc/permissions"
   make_dir "overlay"

   # Copy the files and set the permissions
   for i in $file_list; do
       install_file "$i"
   done

script_text="<permissions>
                    <!-- Shared library required on the device to get Google Dialer updates from
                         Play Store. This will be deprecated once Google Dialer play store
                         updates stop supporting pre-O devices. -->
                    <library name=\"com.google.android.dialer.support\"
                      file=\"$install_partition/framework/com.google.android.dialer.support.jar\" />

                    <!-- Starting from Android O and above, this system feature is required for
                         getting Google Dialer play store updates. -->
                    <feature name=\"com.google.android.apps.dialer.SUPPORTED\" />
                </permissions>"
                echo -e "$script_text" > $install_partition/etc/permissions/com.google.android.dialer.support.xml
                set_perm 0 0 0644 "$install_partition/etc/permissions/com.google.android.dialer.support.xml"
                installPath=$product_prefix"etc/permissions/com.google.android.dialer.support.xml"
                echo "install=$installPath" >> $TMPDIR/addon/$packagePath
                if [ -f "$install_partition/etc/permissions/com.google.android.dialer.support.xml" ]; then
                  addToLog "- $install_partition/etc/permissions/com.google.android.dialer.support.xml Successfully Written!"
                fi
                script_text="<permissions>
                    <library name=\"com.google.android.maps\"
                            file=\"$install_partition/framework/com.google.android.maps.jar\" />
                </permissions>"
                echo -e "$script_text" > $install_partition/etc/permissions/com.google.android.maps.xml
                set_perm 0 0 0644 "$install_partition/etc/permissions/com.google.android.maps.xml"
                installPath=$product_prefix"etc/permissions/com.google.android.maps.xml"
                echo "install=$installPath" >> $TMPDIR/addon/$packagePath
                if [ -f "$install_partition/etc/permissions/com.google.android.maps.xml" ]; then
                  addToLog "- $install_partition/etc/permissions/com.google.android.maps.xml Successfully Written!"
                fi
                        script_text="<permissions>
            <library name=\"com.google.widevine.software.drm\"
                file=\"/system/product/framework/com.google.widevine.software.drm.jar\"/>
        </permissions>"
                        echo -e "$script_text" > $install_partition/etc/permissions/com.google.widevine.software.drm.xml
                        set_perm 0 0 0644 "$install_partition/etc/permissions/com.google.widevine.software.drm.xml"
                        installPath=$product_prefix"etc/permissions/com.google.widevine.software.drm.xml"
                        echo "install=$installPath" >> $TMPDIR/addon/$packagePath
                        if [ -f "$install_partition/etc/permissions/com.google.widevine.software.drm.xml" ]; then
                          addToLog "- $install_partition/etc/permissions/com.google.widevine.software.drm.xml Successfully Written!"
                        fi
                        script_text="<permissions>
            <library name=\"com.google.android.media.effects\"
                    file=\"$install_partition/framework/com.google.android.media.effects.jar\" />

        </permissions>"
                        echo -e "$script_text" > $install_partition/etc/permissions/com.google.android.media.effects.xml
                        set_perm 0 0 0644 "$install_partition/etc/permissions/com.google.android.media.effects.xml"
                        installPath=$product_prefix"etc/permissions/com.google.android.media.effects.xml"
                        echo "install=$installPath" >> $TMPDIR/addon/$packagePath
                        if [ -f "$install_partition/etc/permissions/com.google.android.media.effects.xml" ]; then
                          addToLog "- $install_partition/etc/permissions/com.google.android.media.effects.xml Successfully Written!"
                        fi
   chmod 755 "$COMMONDIR/addon";
   if [ -f "$propFilePath" ]; then
       echo "install=$(echo "$propFilePath" | sed "s|^$system/||")" >>"$TMPDIR/addon/$packagePath"
       addToLog "- Adding $propFilePath to $TMPDIR/addon/$packagePath"
   fi
   . $COMMONDIR/addon "$OFD" "ExtraFiles" "$TMPDIR/addon/$packagePath" "$propFilePath" ""
   copy_file "$TMPDIR/addon/$packagePath" "$logDir/addonfiles/$packagePath.addon"
   rm -rf "$TMPDIR/addon/$packagePath"
   copy_file "$propFilePath" "$logDir/addonfiles/$package_title.prop"
}

find_install_mode

