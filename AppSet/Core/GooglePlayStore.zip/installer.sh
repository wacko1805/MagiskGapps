#!/sbin/sh
configValue="$1"
nikgapps_config_file_name="$2"
install_partition="$3"

make_dir() {
  addToLog "- Creating Directory: $install_partition/$1"
  mkdir -p "$install_partition/$1"
  set_perm 1000 1000 0755 "$install_partition/$1"
}

get_prop_file_path() {
  propFilePath=""
  for i in $(find /system/etc/permissions -iname "$package_title.prop" 2>/dev/null;); do
    prop_file_path="$i"
    addToLog "- Found prop file: $prop_file_path"
    break
  done
  addToLog "- Prop file path before: $prop_file_path"
  [ -z "$prop_file_path" ] && prop_file_path="/system/etc/permissions/$package_title.prop"
  addToLog "- Prop file path after: $prop_file_path"
  echo "$prop_file_path"
}
# Initialize the variables
default_partition="product"
clean_flash_only="false"
product_prefix=$(find_product_prefix "$install_partition")
title="Phonesky"
package_title="GooglePlayStore"
pkg_size="56748"
package_name="com.android.vending"
packagePath=installGooglePlayStoreFiles
deleteFilesPath=deleteGooglePlayStoreFiles
propFilePath=$(get_prop_file_path)

remove_aosp_apps_from_rom="
"

file_list="
___priv-app___Phonesky/Phonesky.apk
___etc___permissions/com.android.vending.xml
"

remove_existing_package() {
   # remove the existing folder for clean install of GooglePlayStore
   delete_package "Phonesky"
}

remove_aosp_apps() {
   # Delete the folders that we want to remove with installing GooglePlayStore
   for i in $remove_aosp_apps_from_rom; do
       RemoveAospAppsFromRom "$i" "$propFilePath"
   done
}

install_package() {
   remove_existing_package
   remove_aosp_apps
   # Create folders and set the permissions
   make_dir "priv-app/Phonesky"
   make_dir "etc/permissions"

   # Copy the files and set the permissions
   for i in $file_list; do
       install_file "$i"
   done

   chmod 755 "$COMMONDIR/addon";
   if [ -f "$propFilePath" ]; then
       echo "install=$(echo "$propFilePath" | sed "s|^$system/||")" >>"$TMPDIR/addon/$packagePath"
       addToLog "- Adding $propFilePath to $TMPDIR/addon/$packagePath"
   fi
   . $COMMONDIR/addon "$OFD" "GooglePlayStore" "$TMPDIR/addon/$packagePath" "$propFilePath" ""
   copy_file "$TMPDIR/addon/$packagePath" "$logDir/addonfiles/$packagePath.addon"
   rm -rf "$TMPDIR/addon/$packagePath"
   copy_file "$propFilePath" "$logDir/addonfiles/$package_title.prop"
}

find_install_mode

