#!/sbin/sh
configValue="$1"
nikgapps_config_file_name="$2"
install_partition="$3"

make_dir() {
  addToLog "- Creating Directory: $install_partition/$1"
  mkdir -p "$install_partition/$1"
  set_perm 1000 1000 0755 "$install_partition/$1"
}

get_prop_file_path() {
  propFilePath=""
  for i in $(find /system/etc/permissions -iname "$package_title.prop" 2>/dev/null;); do
    prop_file_path="$i"
    addToLog "- Found prop file: $prop_file_path"
    break
  done
  addToLog "- Prop file path before: $prop_file_path"
  [ -z "$prop_file_path" ] && prop_file_path="/system/etc/permissions/$package_title.prop"
  addToLog "- Prop file path after: $prop_file_path"
  echo "$prop_file_path"
}
# Initialize the variables
default_partition="product"
clean_flash_only="false"
product_prefix=$(find_product_prefix "$install_partition")
title="PrebuiltGmsCoreSc"
package_title="GmsCore"
pkg_size="117324"
package_name="com.google.android.gms"
packagePath=installGmsCoreFiles
deleteFilesPath=deleteGmsCoreFiles
propFilePath=$(get_prop_file_path)

remove_aosp_apps_from_rom="
PrebuiltGmsCoreQt
PrebuiltGmsCoreRvc
GmsCore
"

file_list="
___priv-app___m_independent/AndroidPlatformServices.apk
___priv-app___PrebuiltGmsCore/PrebuiltGmsCoreSc.apk
___etc___permissions/com.google.android.gms.xml
"

remove_existing_package() {
   # remove the existing folder for clean install of GmsCore
   delete_package "PrebuiltGmsCoreSc"
}

remove_aosp_apps() {
   # Delete the folders that we want to remove with installing GmsCore
   for i in $remove_aosp_apps_from_rom; do
       RemoveAospAppsFromRom "$i" "$propFilePath"
   done
}

install_package() {
   remove_existing_package
   remove_aosp_apps
   # Create folders and set the permissions
   make_dir "priv-app/m_independent"
   make_dir "priv-app/PrebuiltGmsCore"
   make_dir "etc/permissions"

   # Copy the files and set the permissions
   for i in $file_list; do
       install_file "$i"
   done


    gms_optimization=$(ReadConfigValue "gms_optimization" "$nikgapps_config_file_name")
    [ -z "$gms_optimization" ] && gms_optimization=0
    if [ "$gms_optimization" = "1" ]; then
        sed -i '/allow-in-power-save package="com.google.android.gms"/d' $install_partition/etc/permissions/*.xml
        sed -i '/allow-in-data-usage-save package="com.google.android.gms"/d' $install_partition/etc/permissions/*.xml
        sed -i '/allow-unthrottled-location package="com.google.android.gms"/d' $install_partition/etc/permissions/*.xml
        sed -i '/allow-ignore-location-settings package="com.google.android.gms"/d' $install_partition/etc/permissions/*.xml
        addToLog "- Battery Optimization Done in $install_partition/etc/permissions/*.xml!"
        sed -i '/allow-in-power-save package="com.google.android.gms"/d' $install_partition/etc/sysconfig/*.xml
        sed -i '/allow-in-data-usage-save package="com.google.android.gms"/d' $install_partition/etc/sysconfig/*.xml
        sed -i '/allow-unthrottled-location package="com.google.android.gms"/d' $install_partition/etc/sysconfig/*.xml
        sed -i '/allow-ignore-location-settings package="com.google.android.gms"/d' $install_partition/etc/sysconfig/*.xml
        addToLog "- Battery Optimization Done in $install_partition/etc/sysconfig/*.xml!"
    else
        addToLog "- Battery Optimization not Enabled"
    fi
        
   chmod 755 "$COMMONDIR/addon";
   if [ -f "$propFilePath" ]; then
       echo "install=$(echo "$propFilePath" | sed "s|^$system/||")" >>"$TMPDIR/addon/$packagePath"
       addToLog "- Adding $propFilePath to $TMPDIR/addon/$packagePath"
   fi
   . $COMMONDIR/addon "$OFD" "GmsCore" "$TMPDIR/addon/$packagePath" "$propFilePath" ""
   copy_file "$TMPDIR/addon/$packagePath" "$logDir/addonfiles/$packagePath.addon"
   rm -rf "$TMPDIR/addon/$packagePath"
   copy_file "$propFilePath" "$logDir/addonfiles/$package_title.prop"
}

find_install_mode

