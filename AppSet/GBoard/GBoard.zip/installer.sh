#!/sbin/sh
configValue="$1"
nikgapps_config_file_name="$2"
install_partition="$3"

make_dir() {
  addToLog "- Creating Directory: $install_partition/$1"
  mkdir -p "$install_partition/$1"
  set_perm 1000 1000 0755 "$install_partition/$1"
}

get_prop_file_path() {
  propFilePath=""
  for i in $(find /system/etc/permissions -iname "$package_title.prop" 2>/dev/null;); do
    prop_file_path="$i"
    addToLog "- Found prop file: $prop_file_path"
    break
  done
  addToLog "- Prop file path before: $prop_file_path"
  [ -z "$prop_file_path" ] && prop_file_path="/system/etc/permissions/$package_title.prop"
  addToLog "- Prop file path after: $prop_file_path"
  echo "$prop_file_path"
}
# Initialize the variables
default_partition="product"
clean_flash_only="true"
product_prefix=$(find_product_prefix "$install_partition")
title="LatinIMEGooglePrebuilt"
package_title="GBoard"
pkg_size="184284"
package_name="com.google.android.inputmethod.latin"
packagePath=installGBoardFiles
deleteFilesPath=deleteGBoardFiles
propFilePath=$(get_prop_file_path)

remove_aosp_apps_from_rom="
LatinIME
"

file_list="
___usr___srec___en-US/g2p_phonemes.syms
___usr___srec___en-US/g2p
___usr___srec___en-US/config.pumpkin
___usr___srec___en-US/SODA_punctuation_config.pb
___usr___srec___en-US/g2p.syms
___usr___srec___en-US/hotword.data
___usr___srec___en-US/semantics.pumpkin
___usr___srec___en-US/offline_action_data.pb
___usr___srec___en-US/metadata
___usr___srec___en-US/monastery_config.pumpkin
___usr___srec___en-US/SODA_punctuation_model.tflite
___usr___srec___en-US/pumpkin.mmap
___usr___srec___en-US/magic_mic/MARBLE_V2_acoustic_model.int8.tflite
___usr___srec___en-US/magic_mic/MARBLE_V2_model.int8.tflite
___usr___srec___en-US/magic_mic/MARBLE_V2_vocabulary.syms
___usr___srec___en-US/magic_mic/MARBLE_V2_acoustic_meanstddev_vector
___usr___srec___en-US/acousticmodel/MARBLE_VOICE_ACTIONS_EP.endpointer_portable_lstm_mean_stddev
___usr___srec___en-US/acousticmodel/MARBLE_DICTATION_EP.endpointer_portable_lstm_mean_stddev
___usr___srec___en-US/acousticmodel/MARBLE_VOICE_ACTIONS_EP.endpointer_portable_lstm_model
___usr___srec___en-US/acousticmodel/MARBLE_DICTATION_EP.endpointer_portable_lstm_model
___usr___srec___en-US/denorm/embedded_covid_19.mfar
___usr___srec___en-US/denorm/embedded_replace_annotated_punct_words_dash.mfar
___usr___srec___en-US/denorm/embedded_class_denorm.mfar
___usr___srec___en-US/denorm/embedded_fix_ampm.mfar
___usr___srec___en-US/denorm/porn_normalizer_on_device.mfar
___usr___srec___en-US/denorm/embedded_normalizer.mfar
___usr___srec___en-US/endtoendmodel/marble_rnnt_model.syms.compact
___usr___srec___en-US/endtoendmodel/marble_rnnt_model-rnnt.joint.tflite
___usr___srec___en-US/endtoendmodel/marble_rnnt_model-encoder.part_0.tflite
___usr___srec___en-US/endtoendmodel/marble_rnnt_model-rnnt.decoder.tflite
___usr___srec___en-US/endtoendmodel/marble_rnnt_voice_actions_frontend_params.mean_stddev
___usr___srec___en-US/endtoendmodel/marble_rnnt_model.word_classifier
___usr___srec___en-US/endtoendmodel/marble_rnnt_model.wpm.portable
___usr___srec___en-US/endtoendmodel/marble_rnnt_model-encoder.part_1.tflite
___usr___srec___en-US/endtoendmodel/marble_rnnt_dictation_frontend_params.mean_stddev
___usr___srec___en-US/context_prebuilt/en-US_android-auto_manual_fixes_STD_FST.fst
___usr___srec___en-US/context_prebuilt/apps.txt
___usr___srec___en-US/context_prebuilt/songs.txt
___usr___srec___en-US/context_prebuilt/en-US_android-auto_car_automation.action.union_STD_FST.fst
___usr___srec___en-US/context_prebuilt/contacts.txt
___usr___srec___en-US/context_prebuilt/en-US_android-auto_top_radio_station_frequencies_STD_FST.fst
___usr___srec___en-US/configs/ONDEVICE_MEDIUM_SHORT_compiler.config
___usr___srec___en-US/configs/ONDEVICE_MEDIUM_CONTINUOUS.config
___usr___srec___en-US/configs/ONDEVICE_MEDIUM_SHORT.config
___usr___srec___en-US/voice_match/MARBLE_speakerid.tflite
___lib/libjni_latinimegoogle.so
___lib64/libjni_latinimegoogle.so
___app___LatinIMEGooglePrebuilt/LatinIMEGooglePrebuilt.apk
___usr___share___ime___google___d3_lms/ko_2018030706.zip
___usr___share___ime___google___d3_lms/zh_CN_2018030706.zip
___usr___share___ime___google___d3_lms/mozc.data
"

remove_existing_package() {
   # remove the existing folder for clean install of GBoard
   delete_package "LatinIMEGooglePrebuilt"
}

remove_aosp_apps() {
   # Delete the folders that we want to remove with installing GBoard
   for i in $remove_aosp_apps_from_rom; do
       RemoveAospAppsFromRom "$i" "$propFilePath"
   done
}

install_package() {
   remove_existing_package
   remove_aosp_apps
   # Create folders and set the permissions
   make_dir "usr"
   make_dir "usr/srec"
   make_dir "usr/srec/en-US"
   make_dir "lib"
   make_dir "lib64"
   make_dir "app"
   make_dir "app/LatinIMEGooglePrebuilt"
   make_dir "usr/share"
   make_dir "usr/share/ime"
   make_dir "usr/share/ime/google"
   make_dir "usr/share/ime/google/d3_lms"

   # Copy the files and set the permissions
   for i in $file_list; do
       install_file "$i"
   done
   install_file "___etc___permissions/GBoard.prop"


   set_prop "ro.com.google.ime.bs_theme" "true" "$install_partition/build.prop"
   set_prop "ro.com.google.ime.theme_id" "5" "$install_partition/build.prop"
   set_prop "ro.com.google.ime.system_lm_dir" "$install_partition/usr/share/ime/google/d3_lms" "$install_partition/build.prop"
        
   chmod 755 "$COMMONDIR/addon";
   if [ -f "$propFilePath" ]; then
       echo "install=$(echo "$propFilePath" | sed "s|^$system/||")" >>"$TMPDIR/addon/$packagePath"
       addToLog "- Adding $propFilePath to $TMPDIR/addon/$packagePath"
   fi
   . $COMMONDIR/addon "$OFD" "GBoard" "$TMPDIR/addon/$packagePath" "$propFilePath" ""
   copy_file "$TMPDIR/addon/$packagePath" "$logDir/addonfiles/$packagePath.addon"
   rm -rf "$TMPDIR/addon/$packagePath"
   copy_file "$propFilePath" "$logDir/addonfiles/$package_title.prop"
}

find_install_mode

