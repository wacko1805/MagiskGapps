#!/sbin/sh

uninstall_package() {
    ui_print "- Uninstalling $package_title"
    # Remove the files when we're uninstalling NiKGapps
    for i in $file_list; do
        uninstall_file "$i" "$package_name"
    done

    addon_file="51-"$package_title".sh"
    # Removing the addon sh so it doesn't get backed up and restored
    addToLog "- Removing $addon_file"
    rm -rf "/system/addon.d/$addon_file"
    # Removing the updates and residue
    if [ -n "$2" ]; then
        for i in $(find /data -iname "*$2*" 2>/dev/null); do
            if [ -e "$i" ] || [ -d "$1"]; then
                addToLog "- contents matching $2 found at $i"
                rm -rf "$i"
            fi
        done
    fi
}

# Initialize the variables
clean_flash_only="false"
title="GoogleMaps"
package_title="GoogleMaps"
package_name="com.google.android.apps.maps"

file_list="
___etc___permissions/com.google.android.apps.maps.xml
___priv-app___GoogleMaps___lib___arm64/libnative_crash_handler_jni.so
___priv-app___GoogleMaps___lib___arm64/libmappedcountercacheversionjni.so
___priv-app___GoogleMaps___lib___arm64/libgmm-jni.so
___priv-app___GoogleMaps___lib___arm64/libarcore_sdk_c.so
___priv-app___GoogleMaps___lib___arm64/libarcore_sdk_jni.so
___priv-app___GoogleMaps/GoogleMaps.apk
___priv-app___GoogleMaps/split_config.en.apk
___priv-app___GoogleMaps/split_config.xxhdpi.apk
___priv-app___GoogleMaps/split_config.arm64_v8a.apk
"

uninstall_package
